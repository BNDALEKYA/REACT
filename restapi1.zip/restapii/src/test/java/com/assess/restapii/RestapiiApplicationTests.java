package com.assess.restapii;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestapiiApplicationTests {

	@Test
	void contextLoads() {
	}

}
