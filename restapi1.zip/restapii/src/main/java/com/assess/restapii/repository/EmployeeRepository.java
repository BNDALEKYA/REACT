package com.assess.restapii.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.assess.restapii.model.Employee;


public interface EmployeeRepository  extends JpaRepository<Employee, Integer>{

}
