package com.assess.restapii;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestapiiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestapiiApplication.class, args);
	}

}
