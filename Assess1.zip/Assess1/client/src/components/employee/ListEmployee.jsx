import React from "react";
import { useState, useEffect } from "react";
import PropTypes from "prop-types";
import axios from "axios";

import {
  Badge,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Col,
  Pagination,
  PaginationItem,
  PaginationLink,
  Row,
  Table,
} from "reactstrap";

const ListEmployee = (props) => {
  const [data, setData] = useState([]);
  useEffect(() => {
    const GetData = async () => {
      const result = await axios("http://localhost:9000/api/employee/all");
      console.log(result.data);
      setData(result.data);
    };

    GetData();
  }, []);
  const deleteemployee = (employeeId) => {
    axios
      .delete("http://localhost:9000/api/employee/delete/" + employeeId)
      .then((result) => {
        props.history.push("/");
      });
  };
  const editemployee = (id) => {
    props.history.push({
      pathname: "/edit/" + id,
    });
  };
  const viewemployee = (id) => {
    props.history.push({
      pathname: "/edit/" + id,
    });
  };

  return (
    <div className="animated fadeIn">
      <Row>
        <Col>
          <Card>
            <CardHeader>
              <i className="fa fa-align-justify"></i> Employee List
            </CardHeader>

            <CardBody>
              <Table hover bordered striped responsive size="sm">
                <thead>
                  <tr>
                    <th>Employee Id</th>

                    <th>FirstName</th>

                    <th>LastName</th>

                    <th>Department</th>

                    <th>Email</th>

                    <th>Gender</th>
                  </tr>
                </thead>

                <tbody>
                  {data.map((item, idx) => {
                    return (
                      <tr>
                        <td>{item.employeeId}</td>

                        <td>{item.firstName}</td>

                        <td>{item.lastName}</td>

                        <td>{item.department}</td>

                        <td>{item.email}</td>

                        <td>{item.gender}</td>

                        <td>
                          <div class="btn-group">
                            <button
                              className="btn btn-warning"
                              onClick={() => {
                                editemployee(item.employeeId);
                              }}
                            >
                              Edit
                            </button>

                            <button
                              className="btn btn-warning"
                              onClick={() => {
                                deleteemployee(item.employeeId);
                              }}
                            >
                              Delete
                            </button>

                            <button
                              className="btn btn-warning"
                              onClick={() => {
                                viewemployee(item.employeeId);
                              }}
                            >
                              View
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </Table>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

ListEmployee.propTypes = {};

export default ListEmployee;
